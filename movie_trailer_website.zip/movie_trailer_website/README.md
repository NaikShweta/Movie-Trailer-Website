# Movie Trailer Website

This website shows **movie trailers** by clicking on their **poster**
Best works on **Google Chrome**

## Contribution
To add your own movies on this website you should have **Python 2.7** or greater version.

* Add new movies in entertainment.py file by creating new objects of _class Movie_ in media.py file
* Update the movies list at end of the entertainment.py file
* Run the entertainment.py file to generate your HTML page

